"""Pairwise similarity between the scenarios of each generated system.

Each scenario is embedded with three sentence-embedding models and compared by
cosine similarity, on each scenario's full text and on each free-text field.
For every export in ./exports this writes ./outputs/<export>/ with:

    similarity.txt   one similarity matrix per system and model (also printed)
    similarity.json  all matrices, every pair's scores, nearest neighbours

Run from post_genration_work/:

    uv run similar_scenarios_analysis/scenario_similarity.py
    uv run similar_scenarios_analysis/scenario_similarity.py \
        similar_scenarios_analysis/exports/Few-shot-rep1-export.json
"""

import argparse
import json
import sys
from itertools import combinations
from pathlib import Path

import numpy as np
from sentence_transformers import SentenceTransformer
from tqdm import tqdm

HERE = Path(__file__).resolve().parent

MODELS = [
    "cisco-ai/SecureBERT2.0-biencoder",  # cybersecurity-domain ModernBERT bi-encoder
    "BAAI/bge-large-en-v1.5",  # general-domain embedder
    "Qwen/Qwen3-Embedding-0.6B",  # general-domain embedder, recent MTEB leader
]

TEXT_FIELDS = ["actor", "trigger", "standing_state", "outcome", "narrative"]
# Asset and threat are one to five words, so they are compared by exact match.
EXACT_FIELDS = ["asset", "threat"]
FULL_TEXT_FIELDS = ["actor", "trigger", "standing_state", "asset", "threat", "outcome", "narrative"]
FIELDS = ["full_text"] + TEXT_FIELDS


def full_text(sc):
    return "\n".join(f"{f.replace('_', ' ').title()}: {(sc[f] or '').strip()}" for f in FULL_TEXT_FIELDS)


def field_text(sc, field):
    return full_text(sc) if field == "full_text" else (sc[field] or "").strip()


def log(msg):
    tqdm.write(msg, file=sys.stderr)


def load_export(path):
    data = json.loads(path.read_text())
    systems = []
    for system in sorted(data["systems"], key=lambda s: (s["variant"], s["id"])):
        scenarios = sorted((sc for sc in data["scenarios"] if sc["system_description"] == system["id"]),
                           key=lambda sc: sc["order"])
        systems.append({"system": system, "scenarios": scenarios})
    return data, systems


def embed_all(exports):
    """cosine[model][(export, system_id, field)] = scenario-by-scenario cosine matrix."""
    cosine = {}
    jobs = [(path.name, entry) for path, _, systems in exports for entry in systems]
    for model_id in tqdm(MODELS, desc="models", unit="model"):
        log(f"loading {model_id}")
        model = SentenceTransformer(model_id)
        cosine[model_id] = {}
        for export_name, entry in tqdm(jobs, desc=model_id.split("/")[-1], unit="system", leave=False):
            for field in FIELDS:
                texts = [field_text(sc, field) for sc in entry["scenarios"]]
                emb = model.encode(texts, normalize_embeddings=True, batch_size=8, show_progress_bar=False)
                cosine[model_id][(export_name, entry["system"]["id"], field)] = emb @ emb.T
        del model
    return cosine


def r4(x):
    return round(float(x), 4)


def score_system(export_name, entry, cosine):
    scenarios = entry["scenarios"]
    labels = [sc["scenario_id"] for sc in scenarios]
    mats = {m: {f: cosine[m][(export_name, entry["system"]["id"], f)] for f in FIELDS} for m in MODELS}
    idx_pairs = list(combinations(range(len(labels)), 2))

    pairs = []
    for i, j in idx_pairs:
        a, b = scenarios[i], scenarios[j]
        pairs.append({
            "a": labels[i],
            "b": labels[j],
            **{f"same_{f}": (a[f] or "").strip().lower() == (b[f] or "").strip().lower() for f in EXACT_FIELDS},
            "full_text_cosine_mean": r4(np.mean([mats[m]["full_text"][i, j] for m in MODELS])),
            "cosine": {m: {f: r4(mats[m][f][i, j]) for f in FIELDS} for m in MODELS},
        })
    pairs.sort(key=lambda p: p["full_text_cosine_mean"], reverse=True)

    nearest = {}
    for i, label in enumerate(labels):
        nearest[label] = {}
        for m in MODELS:
            row = mats[m]["full_text"][i].copy()
            row[i] = -np.inf
            j = int(np.argmax(row))
            nearest[label][m] = {"scenario": labels[j], "full_text_cosine": r4(row[j])}

    per_model = {}
    for m in MODELS:
        off = [mats[m]["full_text"][i, j] for i, j in idx_pairs]
        per_model[m] = {"full_text_cosine_mean": r4(np.mean(off)), "full_text_cosine_min": r4(min(off)),
                        "full_text_cosine_max": r4(max(off))}

    system = entry["system"]
    return {
        "system_id": system["id"],
        "title": system["title"],
        "variant": system["variant"],
        "generation_run": system["generation_run"],
        "scenarios": [{"scenario_id": sc["scenario_id"], "db_id": sc["id"], "asset": sc["asset"],
                       "threat": sc["threat"], "outcome": sc["outcome"]} for sc in scenarios],
        "summary": per_model,
        "nearest_neighbour": nearest,
        "pairs": pairs,
        "matrices": {"order": labels,
                     **{m: {f: [[r4(v) for v in row] for row in mats[m][f]] for f in FIELDS} for m in MODELS}},
    }


def matrix_lines(labels, matrix, ansi, top=3):
    """The matrix with the `top` most similar pairs starred, and underlined in a terminal."""
    n = len(labels)
    ranked = sorted(combinations(range(n), 2), key=lambda ij: matrix[ij[0]][ij[1]], reverse=True)
    marked = {cell for i, j in ranked[:top] for cell in ((i, j), (j, i))}
    width = max(len(label) for label in labels) + 2
    # Every cell is width + 1 wide; the extra character holds the star.
    lines = [" " * width + "".join(f"{label:>{width}} " for label in labels)]
    for i, (label, row) in enumerate(zip(labels, matrix)):
        cells = []
        for j, v in enumerate(row):
            value = f"{v:.3f}"
            pad = " " * (width - len(value))
            if (i, j) in marked:
                cells.append(pad + (f"\033[4m{value}\033[0m" if ansi else value) + "*")
            else:
                cells.append(pad + value + " ")
        lines.append(f"{label:<{width}}" + "".join(cells))
    return lines


def text_report(result, ansi=False, top_pairs=5):
    lines = [f"Scenario similarity: {result['source_export']} (experiment {result['experiment']})",
             "Cosine similarity of each scenario's full text (all fields); higher means more alike.",
             "* marks the 3 most similar pairs in each matrix.", ""]
    for s in result["systems"]:
        labels = s["matrices"]["order"]
        lines += ["=" * 78,
                  f"System {s['system_id']}: {s['title']} (variant {s['variant']}, run {s['generation_run']})",
                  "=" * 78]
        for sc in s["scenarios"]:
            lines.append(f"  {sc['scenario_id']}  {sc['threat']:<22} {sc['asset']}")
        lines.append("")
        for m in MODELS:
            st = s["summary"][m]
            lines.append(f"{m}  (mean {st['full_text_cosine_mean']:.3f}, "
                         f"min {st['full_text_cosine_min']:.3f}, max {st['full_text_cosine_max']:.3f})")
            lines += matrix_lines(labels, s["matrices"][m]["full_text"], ansi)
            lines.append("")
        lines.append("Most similar pairs (mean over models):")
        scenario_by_id = {sc["scenario_id"]: sc for sc in s["scenarios"]}
        for p in s["pairs"][:top_pairs]:
            flags = ", ".join(f"both {f} {scenario_by_id[p['a']][f].strip()}"
                              for f in EXACT_FIELDS if p[f"same_{f}"])
            lines.append(f"  {p['a']} - {p['b']}  {p['full_text_cosine_mean']:.3f}" + (f"  ({flags})" if flags else ""))
        lines.append("")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("exports", nargs="*", type=Path, help="export files (default: exports/*.json)")
    parser.add_argument("--out", type=Path, default=HERE / "outputs")
    args = parser.parse_args()

    paths = args.exports or sorted((HERE / "exports").glob("*.json"))
    exports = [(p, *load_export(p)) for p in paths]
    cosine = embed_all(exports)

    for path, data, systems in exports:
        result = {
            "source_export": path.name,
            "experiment": data["experiment_current"]["name"],
            "method": {
                "metric": "cosine similarity of L2-normalised sentence embeddings",
                "models": MODELS,
                "fields": FIELDS,
                "full_text": "all of " + ", ".join(FULL_TEXT_FIELDS) + " joined as 'Field: value' lines",
                "exact_match_fields": EXACT_FIELDS,
            },
            "systems": [score_system(path.name, entry, cosine) for entry in systems],
        }
        out_dir = args.out / path.stem.removesuffix("-export")
        out_dir.mkdir(parents=True, exist_ok=True)
        print(text_report(result, ansi=sys.stdout.isatty()))
        (out_dir / "similarity.txt").write_text(text_report(result) + "\n")
        (out_dir / "similarity.json").write_text(json.dumps(result, indent=2, ensure_ascii=False))
        log(f"wrote {out_dir}/similarity.txt and similarity.json")


if __name__ == "__main__":
    main()
